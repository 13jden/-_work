package com.example.inews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InewsApplicationTests {

    @Test
    void contextLoads() {
    }

}
