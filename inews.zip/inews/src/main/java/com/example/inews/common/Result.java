package com.example.inews.common;

public class Result {
}
